package com.smartchat.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.smartchat.core.network.ApiResult
import com.smartchat.data.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel(
    initialConversationId: String?,
    private val chatRepository: ChatRepository
) : ViewModel() {
    private val _state = MutableStateFlow(
        ChatUiState(conversationId = initialConversationId, isLoading = initialConversationId != null)
    )
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    private var messagesJob: Job? = null

    init {
        initialConversationId?.let { conversationId ->
            observeMessages(conversationId)
            viewModelScope.launch {
                when (val result = chatRepository.synchronizeMessages(conversationId)) {
                    is ApiResult.Success -> _state.value = _state.value.copy(isLoading = false)
                    is ApiResult.Error -> _state.value = _state.value.copy(
                        isLoading = false,
                        errorMessage = result.message
                    )
                }
            }
        }
    }

    fun updateInput(value: String) {
        _state.value = _state.value.copy(input = value, errorMessage = null)
    }

    fun send() {
        val content = _state.value.input.trim()
        if (content.isEmpty() || _state.value.isSending) return

        _state.value = _state.value.copy(isSending = true, errorMessage = null)
        viewModelScope.launch {
            val conversationId = getOrCreateConversation(content) ?: return@launch

            when (
                val result = chatRepository.sendMessage(
                    conversationId = conversationId,
                    content = content
                )
            ) {
                is ApiResult.Success -> _state.value = _state.value.copy(
                    isSending = false,
                    input = ""
                )
                is ApiResult.Error -> _state.value = _state.value.copy(
                    isSending = false,
                    errorMessage = result.message
                )
            }
        }
    }

    private suspend fun getOrCreateConversation(firstMessage: String): String? {
        _state.value.conversationId?.let { return it }

        return when (val result = chatRepository.createConversation(firstMessage)) {
            is ApiResult.Success -> {
                observeMessages(result.value)
                _state.value = _state.value.copy(conversationId = result.value)
                result.value
            }
            is ApiResult.Error -> {
                _state.value = _state.value.copy(
                    isSending = false,
                    errorMessage = result.message
                )
                null
            }
        }
    }

    private fun observeMessages(conversationId: String) {
        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            chatRepository.observeMessages(conversationId).collect { messages ->
                _state.value = _state.value.copy(
                    messages = messages.map { item ->
                        ChatMessage(
                            id = item.message.id,
                            sender = item.message.sender,
                            content = item.message.content
                        )
                    }
                )
            }
        }
    }

    class Factory(
        private val conversationId: String?,
        private val chatRepository: ChatRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ChatViewModel(conversationId, chatRepository) as T
    }
}
