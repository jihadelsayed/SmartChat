import { aiService } from "../ai/ai.service";
import { AI_CONTEXT_MESSAGE_LIMIT } from "../ai/ai.constants";
import type { AiChatInput } from "../ai/ai.types";
import { conversationService } from "../conversations/conversation.service";
import { userService } from "../users/user.service";
import { messageRepository } from "./message.repository";

async function generateAndPersistExchange(
  conversationId: string,
  content: string
) {
  const recentMessages =
    await messageRepository.listRecentByConversation(
      conversationId,
      AI_CONTEXT_MESSAGE_LIMIT - 1
    );
  const assistantContent = await aiService.reply(
    content,
    recentMessages.map((message) => ({
      role:
        message.sender === "USER"
          ? "user" as const
          : "assistant" as const,
      content: message.content
    }))
  );

  return messageRepository.createExchange(
    conversationId,
    content,
    assistantContent
  );
}

export const messageService = {
  async list(conversationId: string, userId: string) {
    await conversationService.get(conversationId, userId);

    return messageRepository.listByConversation(conversationId);
  },

  async send(conversationId: string, userId: string, content: string) {
    await conversationService.get(conversationId, userId);

    return generateAndPersistExchange(conversationId, content);
  },

  async sendFromAiChat(input: AiChatInput) {
    await userService.getProfile(input.userId);

    const conversation = input.conversationId
      ? await conversationService.get(input.conversationId, input.userId)
      : await conversationService.create(input.userId);

    return generateAndPersistExchange(conversation.id, input.message);
  }
};
