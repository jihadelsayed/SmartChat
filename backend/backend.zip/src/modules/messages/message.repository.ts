import { prisma } from "../../database/prisma";
import { MessageSender } from "../../generated/prisma/client";

export const messageRepository = {
  listByConversation(conversationId: string) {
    return prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: "asc" },
      include: { attachments: true }
    });
  },

  async listRecentByConversation(
    conversationId: string,
    limit: number
  ) {
    const messages = await prisma.message.findMany({
      where: { conversationId },
      orderBy: [
        { createdAt: "desc" },
        { id: "desc" }
      ],
      take: limit,
      select: {
        sender: true,
        content: true
      }
    });

    return messages.reverse();
  },

  createExchange(
    conversationId: string,
    userContent: string,
    assistantContent: string
  ) {
    return prisma.$transaction(async (transaction) => {
      const userCreatedAt = new Date();
      const assistantCreatedAt = new Date(userCreatedAt.getTime() + 1);
      const userMessage = await transaction.message.create({
        data: {
          conversationId,
          sender: MessageSender.USER,
          content: userContent,
          createdAt: userCreatedAt
        },
        include: {
          attachments: true
        }
      });

      const assistantMessage = await transaction.message.create({
        data: {
          conversationId,
          sender: MessageSender.ASSISTANT,
          content: assistantContent,
          createdAt: assistantCreatedAt
        },
        include: {
          attachments: true
        }
      });

      await transaction.conversation.update({
        where: { id: conversationId },
        data: { updatedAt: assistantCreatedAt }
      });

      return {
        userMessage,
        assistantMessage
      };
    });
  }
};
