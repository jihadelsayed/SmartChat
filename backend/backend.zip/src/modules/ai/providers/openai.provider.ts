import OpenAI, { APIConnectionTimeoutError } from "openai";
import {
  AI_MAXIMUM_RETRIES,
  AI_REQUEST_TIMEOUT_MS
} from "../ai.constants";
import {
  AiConfigurationError,
  AiEmptyResponseError,
  AiProviderError,
  AiRequestTimeoutError
} from "../ai.errors";
import type { AiProviderRequest } from "../ai.types";
import type { AiProvider } from "./ai-provider.interface";

const SMARTCHAT_INSTRUCTIONS =
  "You are SmartChat, a concise and helpful AI assistant.";

type OpenAiClient = Pick<OpenAI, "responses">;

export class OpenAiProvider implements AiProvider {
  private readonly client: OpenAiClient;

  constructor(
    apiKey: string,
    private readonly model: string,
    client?: OpenAiClient
  ) {
    if (!apiKey.trim() || !model.trim()) {
      throw new AiConfigurationError();
    }

    this.client =
      client ??
      new OpenAI({
        apiKey,
        timeout: AI_REQUEST_TIMEOUT_MS,
        maxRetries: AI_MAXIMUM_RETRIES
      });
  }

  async generateReply(input: AiProviderRequest): Promise<string> {
    try {
      const response = await this.client.responses.create({
        model: this.model,
        instructions: input.systemPrompt ?? SMARTCHAT_INSTRUCTIONS,
        input: input.messages
      });
      const generatedText = response.output_text.trim();

      if (!generatedText) {
        throw new AiEmptyResponseError();
      }

      return generatedText;
    } catch (error: unknown) {
      if (error instanceof AiEmptyResponseError) {
        throw error;
      }

      if (error instanceof APIConnectionTimeoutError) {
        throw new AiRequestTimeoutError();
      }

      throw new AiProviderError();
    }
  }
}
