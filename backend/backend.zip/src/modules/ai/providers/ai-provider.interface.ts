import type { AiProviderRequest } from "../ai.types";

export interface AiProvider {
  generateReply(input: AiProviderRequest): Promise<string>;
}
