import { AppError } from "../../shared/errors/app-error";

export class AiConfigurationError extends AppError {
  constructor() {
    super(
      "The AI service is not configured",
      500,
      "AI_CONFIGURATION_ERROR"
    );
  }
}

export class AiProviderError extends AppError {
  constructor() {
    super(
      "The AI service is temporarily unavailable. Please try again.",
      502,
      "AI_PROVIDER_ERROR"
    );
  }
}

export class AiEmptyResponseError extends AppError {
  constructor() {
    super(
      "The AI service returned an empty response. Please try again.",
      502,
      "AI_EMPTY_RESPONSE"
    );
  }
}

export class AiRequestTimeoutError extends AppError {
  constructor() {
    super(
      "The AI service took too long to respond. Please try again.",
      504,
      "AI_REQUEST_TIMEOUT"
    );
  }
}
