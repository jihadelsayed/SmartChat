import assert from "node:assert/strict";
import { test } from "node:test";
import OpenAI, { APIConnectionTimeoutError } from "openai";
import {
  AiConfigurationError,
  AiEmptyResponseError,
  AiProviderError,
  AiRequestTimeoutError
} from "../../src/modules/ai/ai.errors";
import type { AiProviderRequest } from "../../src/modules/ai/ai.types";
import { OpenAiProvider } from "../../src/modules/ai/providers/openai.provider";

type OpenAiClient = Pick<OpenAI, "responses">;

const providerInput: AiProviderRequest = {
  message: "Current question",
  messages: [
    { role: "user", content: "Earlier question" },
    { role: "assistant", content: "Earlier answer" },
    { role: "user", content: "Current question" }
  ]
};

function mockClient(
  create: (request: unknown) => Promise<unknown>
): OpenAiClient {
  return {
    responses: {
      create
    }
  } as unknown as OpenAiClient;
}

test("OpenAI provider sends conversation context through the Responses API", async () => {
  let capturedRequest: unknown;
  const provider = new OpenAiProvider(
    "test-api-key",
    "test-model",
    mockClient(async (request) => {
      capturedRequest = request;
      return { output_text: "  Context-aware reply  " };
    })
  );

  const result = await provider.generateReply(providerInput);

  assert.equal(result, "Context-aware reply");
  assert.deepEqual(capturedRequest, {
    model: "test-model",
    instructions:
      "You are SmartChat, a concise and helpful AI assistant.",
    input: providerInput.messages
  });
});

test("OpenAI provider rejects missing configuration without exposing a key", () => {
  assert.throws(
    () => new OpenAiProvider("", "test-model"),
    AiConfigurationError
  );
});

test("OpenAI provider converts empty responses to a safe application error", async () => {
  const provider = new OpenAiProvider(
    "test-api-key",
    "test-model",
    mockClient(async () => ({ output_text: "   " }))
  );

  await assert.rejects(
    provider.generateReply(providerInput),
    AiEmptyResponseError
  );
});

test("OpenAI provider converts timeouts to a safe application error", async () => {
  const provider = new OpenAiProvider(
    "test-api-key",
    "test-model",
    mockClient(async () => {
      throw new APIConnectionTimeoutError({
        message: "internal timeout detail"
      });
    })
  );

  await assert.rejects(
    provider.generateReply(providerInput),
    AiRequestTimeoutError
  );
});

test("OpenAI provider hides provider error internals", async () => {
  const provider = new OpenAiProvider(
    "test-api-key",
    "test-model",
    mockClient(async () => {
      throw new Error("private upstream failure detail");
    })
  );

  await assert.rejects(
    provider.generateReply(providerInput),
    (error: unknown) => {
      assert.ok(error instanceof AiProviderError);
      assert.doesNotMatch(error.message, /private upstream/i);
      return true;
    }
  );
});
